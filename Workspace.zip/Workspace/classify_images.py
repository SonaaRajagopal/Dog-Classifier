#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND-revision/intropyproject-classify-pet-images/classify_images.py
#                                                                             
# PROGRAMMER: Sonaa Rajagopal
# DATE CREATED:    10-11-2023                             
# REVISED DATE: 
# PURPOSE: Create a function classify_images that uses the classifier function 
#          to create the classifier labels and then compares the classifier 
#          labels to the pet image labels. This function inputs:
#            -The Image Folder as image_dir within classify_images and function 
#             and as in_arg.dir for function call within main. 
#            -The results dictionary as results_dic within classify_images 
#             function and results for the functin call within main.
#            -The CNN model architecture as model wihtin classify_images function
#             and in_arg.arch for the function call within main. 
#           This function uses the extend function to add items to the list 
#           that's the 'value' of the results dictionary. You will be adding the
#           classifier label as the item at index 1 of the list and the comparison 
#           of the pet and classifier labels as the item at index 2 of the list.
#
##
# Imports only listdir function from OS module
from os import listdir

# Imports classifier function for using CNN to classify images
from classifier import classifier

def get_pet_labels(images_dir):
    """
    Reads the filenames from a folder and creates a dictionary of pet image labels.

    Parameters:
    images_dir (str): The path to the folder containing pet images.

    Returns:
    dict: A dictionary where filenames are keys and pet image labels are values.
    """
    filename_list = listdir(images_dir)
    pet_labels_dic = {}

    for filename in filename_list:
        pet_label = filename.lower().split("_")
        pet_name = ""
        for word in pet_label:
            if word.isalpha():
                pet_name += word + " "
        pet_labels_dic[filename] = pet_name.strip()

    return pet_labels_dic

def classify_images(images_dir, results_dic, model):
    """
    Creates classifier labels with the classifier function, compares pet labels to 
    the classifier labels, and adds the classifier label and the comparison of 
    the labels to the results dictionary using the extend function. Be sure to
    format the classifier labels so that they will match your pet image labels.
    The format will include putting the classifier labels in all lowercase 
    letters and stripping the leading and trailing whitespace characters from them.

    Parameters: 
      images_dir (str): The path to the folder of images that are to be
                       classified by the classifier function.
      results_dic (dict): Results Dictionary with 'key' as image filename and 'value'
                         as a List.
      model (str): Indicates which CNN model architecture will be used by the 
                   classifier function to classify the pet images.
                   Values must be either: resnet, alexnet, vgg.

    Returns:
      None - results_dic is a mutable data type so no return needed.         
    """
    for filename in results_dic:
        image_path = images_dir + filename
        classifier_label = classifier(image_path, model).lower().strip()
        results_dic[filename].extend([classifier_label, int(results_dic[filename][0] in classifier_label)])

def adjust_results4_isadog(results_dic, dogfile):
    """
    Adjusts the results dictionary to determine if the classifier correctly
    classified images as 'a dog' or 'not a dog'.

    Parameters:
      results_dic (dict): Results Dictionary with 'key' as image filename and 'value'
                         as a List.
      dogfile (str): The path to the file that contains dog names.

    Returns:
      None - results_dic is a mutable data type so no return needed.
    """
    with open(dogfile, 'r') as file:
        dog_names = file.read().splitlines()

    for filename in results_dic:
        is_dog = int(results_dic[filename][0] in dog_names)
        results_dic[filename].extend([is_dog, int(results_dic[filename][1] in dog_names)])

def calculates_results_stats(results_dic):
    """
    Creates the results statistics dictionary that contains a
    summary of the results statistics.

    Parameters:
      results_dic (dict): Results Dictionary with 'key' as image filename and 'value'
                         as a List.

    Returns:
      dict: Results Statistics Dictionary with counts and percentages.
    """
    results_stats = {
        'n_images': len(results_dic),
        'n_dogs_img': sum(results_dic[filename][3] for filename in results_dic if results_dic[filename][3]),
        'n_notdogs_img': sum(1 for filename in results_dic if not results_dic[filename][3]),
        'n_correct_dogs': sum(results_dic[filename][4] for filename in results_dic if results_dic[filename][3] and results_dic[filename][4]),
        'n_correct_notdogs': sum(1 for filename in results_dic if not results_dic[filename][3] and not results_dic[filename][4]),
        'n_correct_breed': sum(results_dic[filename][2] for filename in results_dic if results_dic[filename][3] and results_dic[filename][2]),
        'n_dog_images': sum(results_dic[filename][3] for filename in results_dic),
        'n_correct_dogs': sum(results_dic[filename][3] and results_dic[filename][4] for filename in results_dic),
        'n_correct_notdogs': sum(not results_dic[filename][3] and not results_dic[filename][4] for filename in results_dic),
        'n_correct_breed': sum(results_dic[filename][2] for filename in results_dic),
        'n_label_match': sum(results_dic[filename][2] for filename in results_dic),
        'n_correct_notdogs': sum(not results_dic[filename][3] and not results_dic[filename][4] for filename in results_dic),
    }

    results_stats['pct_correct_dogs'] = results_stats['n_correct_dogs'] / results_stats['n_dog_images'] * 100 if results_stats['n_dog_images'] > 0 else 0.0
    results_stats['pct_correct_notdogs'] = results_stats['n_correct_notdogs'] / results_stats['n_notdogs_img'] * 100 if results_stats['n_notdogs_img'] > 0 else 0.0
    results_stats['pct_correct_breed'] = results_stats['n_correct_breed'] / results_stats['n_dog_images'] * 100 if results_stats['n_dog_images'] > 0 else 0.0

    return results_stats

def print_results(results_dic, results_stats, model, print_incorrect_dogs, print_incorrect_breed):
    """
    Prints summary results, incorrect classifications of dogs (if requested),
    and incorrectly classified breeds (if requested).

    Parameters:
      results_dic (dict): Results Dictionary with 'key' as image filename and 'value'
                         as a List.
      results_stats (dict): Results Statistics Dictionary with counts and percentages.
      model (str): Indicates which CNN model architecture was used.
      print_incorrect_dogs (bool): Whether to print incorrect dog classifications.
      print_incorrect_breed (bool): Whether to print incorrect breed classifications.

    Returns:
      None
    """
    print("\nSummary Statistics for CNN Model Architecture", model.upper())
    print("Number of Images: {}".format(results_stats['n_images']))
    print("Number of Dog Images: {}".format(results_stats['n_dogs_img']))
    print("Number of Not-a-Dog Images: {}".format(results_stats['n_notdogs_img']))

    print("\nResults for {} CNN Model Architecture:".format(model.upper()))
    print("Percentage of Correct Dogs: {:.2f}%".format(results_stats['pct_correct_dogs']))
    print("Percentage of Correct Not-a-Dogs: {:.2f}%".format(results_stats['pct_correct_notdogs']))
    print("Percentage of Correct Breed: {:.2f}%".format(results_stats['pct_correct_breed']))

    if print_incorrect_dogs and (results_stats['n_correct_dogs'] + results_stats['n_correct_notdogs'] != results_stats['n_images']):
        print("\nIncorrect Dog/Not Dog Assignments:")
        for filename in results_dic:
            if sum(results_dic[filename][3:]) == 1:
                print("Real: {:>26}   Classifier: {:>30}".format(results_dic[filename][0], results_dic[filename][1]))

    if print_incorrect_breed and (results_stats['n_correct_dogs'] != results_stats['n_correct_breed']):
        print("\nIncorrect Breed Assignments:")
        for filename in results_dic:
            if sum(results_dic[filename][2:]) == 1 and results_dic[filename][3] == 1:
                print("Real: {:>26}   Classifier: {:>30}".format(results_dic[filename][0], results_dic[filename][1]))

# Example usage:
# Define paths and model
images_dir = "pet_images/"
dogfile = "dognames.txt"
model = "vgg"

# Get pet labels
pet_labels_dic = get_pet_labels(images_dir)

# Initialize results dictionary
results_dic = {filename: [pet_labels_dic[filename]] for filename in pet_labels_dic}

# Classify images
classify_images(images_dir, results_dic, model)

# Adjust results for is-a-dog
adjust_results4_isadog(results_dic, dogfile)

# Calculate results statistics
results_stats = calculates_results_stats(results_dic)

# Print results
print_results(results_dic, results_stats, model, True, True)
