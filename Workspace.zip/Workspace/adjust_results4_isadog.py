def adjust_results4_isadog(results_dic, dogfile):
    try:
        # Read the dog names from the dogfile
        with open(dogfile, 'r') as file:
            dog_names = file.readlines()
    
        # Strip whitespace and convert to lowercase
        dog_names = [name.strip().lower() for name in dog_names]
    except FileNotFoundError:
        print("File not found or cannot be opened.")
        return 
    
    # Iterate through the results_dic and update the values for index 3 and index 4
    for key in results_dic:
        # Check if the pet image label is a dog
        pet_label_is_dog = 1 if results_dic[key][0] in dog_names else 0
        # Check if the classifier label is a dog
        classifier_label_is_dog = 1 if results_dic[key][1] in dog_names else 0
        
        # Update the results_dic with the information
        results_dic[key].extend([pet_label_is_dog, classifier_label_is_dog])
